class AdminController < ApplicationController
def login
end


def authenticate
if params[:username]=="prashanth"&&params[:password]=="password"
redirect_to '/categories'
else
redirect_to '/admin'
end
end

end
