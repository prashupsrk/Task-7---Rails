class CustomerController < ApplicationController
def index
end

def category_display
@category= Category.all
end

def final_page
@product= Product.where("category_id=?",params[:id])

puts @product
end

end
