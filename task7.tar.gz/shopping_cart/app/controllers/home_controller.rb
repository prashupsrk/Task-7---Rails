class HomeController < ApplicationController



end
