Rails.application.routes.draw do
  resources :products
  resources :categories
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html

get '/admin' => 'admin#login'
match ':controller(/:action(/:id))', :via =>:get
root "customer#index"
end
